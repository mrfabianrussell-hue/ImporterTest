# Operations Center

The published private preview is a browser demo. `server/` is the Azure App Service integration package: it serves the same UI and a same-origin `/api/live` endpoint. The browser receives the domain skill names returned to the supervisor and normalized statistics, but never the Five9 password, token, domain routing header, or raw ACD response. The published Site remains a five-skill demo; the local and Azure server request the domain skill catalog.

## Local live validation on Windows

1. Install Node.js 20 or newer. Download and unzip this project to a local folder. No `npm install` is required.
2. Confirm the dedicated Five9 account has the **Supervisor** role, **Execute Web API requests (legacy)** permission, access to the skills you want to monitor, and has completed its first browser sign-in and security questions. The domain must have REST API access enabled.
3. Open PowerShell in the extracted folder and run `./Start-Local.ps1`. Enter the Five9 username and password in the Windows credential prompt. They are not written to a file or sent to the published preview.
4. Once PowerShell says the local dashboard is ready, open `http://localhost:3000` in your browser. Wait roughly 30–60 seconds. Confirm the badge changes from **CONNECTING** to **LIVE FIVE9**, and verify values for calls waiting, longest wait, logged in, ready, on call, and not ready. Reload or wait for the next 30-second snapshot to verify movement. Open `http://localhost:3000/api/live` to inspect the safe JSON response: `status`, `updatedAt`, and each named skill's mapped fields.
5. Press Ctrl+C in PowerShell to stop. The server attempts to log out its Five9 session; the script clears temporary environment variables when it exits. Close the local browser tab when done.

If PowerShell blocks local scripts, use a process-only execution policy for this run: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Start-Local.ps1`. Review the script first if your organization's policy requires it. Do not paste credentials into a chat, command line, or the published preview.

A successful `LIVE FIVE9` status and current `updatedAt` confirm that login, metadata routing, supervisor state, skill discovery, and ACD snapshots worked from your computer. **A dash (`—`) in service level, offered, handled, abandoned, or ACW is expected:** the ACD snapshot does not supply validated mappings for those metrics yet. Do not treat a dash as zero.

### If it does not connect

Open `/api/live` locally and inspect `status` and `message`. Typical causes:

- `Five9 HTTP 401`: username/password, first-time browser sign-in, account challenge, or account lock.
- `Five9 HTTP 403`: Supervisor role, `Execute Web API requests (legacy)` permission, domain REST API enablement, or skill access.
- `Skill unavailable`: the selected skill is absent from the supervisor catalog. Use Manage Views to select a visible skill.
- `Supervisor requires login action`: complete any required maintenance notice or account setup through Five9, then retry.
- `Five9 HTTP 5xx` or a connection error: retry and confirm local network access to the returned Five9 API host with your network team.
- `STALE FIVE9`: the last snapshot remains visible but is no longer current. Check `/api/live` for the time and message.

The published ChatGPT Site remains a private five-skill demo; this local Node server is the live proof of concept with the full supervisor-visible catalog. Run only **one** local instance with the dedicated account to avoid competing supervisor sessions.

## Validate the remaining KPI mappings

After confirming the local **LIVE FIVE9** badge, stop that dashboard with Ctrl+C. In the same extracted folder, run `./Discover-Fields.ps1` and use the dedicated supervisor credentials again. This one-time script queries Five9's REST statistics metadata plus the documented Statistics Web Services `ACDStatus` and `InboundCampaignStatistics` snapshots. It creates `five9-field-report.json` in the folder.

Review that JSON before sharing it. It contains skill names, inbound campaign names, selected operational values and field names, but no credentials, tokens, agent names or customer records. Upload the report here so the campaign-to-skill mapping, service-level definition, calls offered/handled/abandoned and ACW can be validated against *your* domain. The selected campaign fields use a **CurrentDay** statistics range. If the SOAP endpoint fails, the report still contains the validated REST skill snapshot and its metadata/error; send the report and the visible error text for follow-up. Do not send the password or a raw Five9 response.

Service level and volume are listed in the guide under **Inbound Campaign Statistics**, while ACD Status holds the skill queue counts. A campaign statistic cannot be labeled as a skill statistic until we know the correct campaign-to-skill relationship and the selected time window. ACW is not in the REST ACD snapshot; agent average wrap time, if available, is a different aggregation and should be labeled accordingly.

## Azure integration

1. Create an Azure App Service for Node 20+ and deploy this project. Set startup command `npm start`.
2. In **Authentication**, add Microsoft Entra ID, set **Require authentication**, and choose redirect for unauthenticated website requests. Restrict access to your desired users/groups. The app also checks the injected principal header when `AUTH_REQUIRED=true`, but the platform gate is essential.
3. Assign the App Service a managed identity and grant it **Key Vault Secrets User** for the vault. Set `FIVE9_PASSWORD` to a Key Vault reference in App Service configuration; set `FIVE9_USERNAME`, `FIVE9_ORG_ID`, `FIVE9_SKILL_NAMES`, `FIVE9_POLL_SECONDS`, `AUTH_REQUIRED=true`, `NODE_ENV=production` there as well. No `.env` file is deployed.
4. Use a dedicated Supervisor account with **Execute Web API requests (legacy)**, completed first-time sign-in/security questions, and access to the five skills. Confirm Agent Desktop Plus and Supervisor Plus plus **Enable Access to the REST API** for the domain.
5. Verify `/api/live` after sign-in. It should change from `connecting` to `live`, report the five exact skill names, and show `updatedAt`. `error` or `stale` leaves numbers unavailable or shows their last observed values with an explicit stale status.

This adapter uses Supervisor REST login → metadata → routed requests → empty station session → queue discovery → ACD snapshots at a 30-second default interval. The documented REST ping is available if the interval is ever extended to an idle period. ACD snapshots confirm waiting calls, longest queue duration, logged-in, ready, on-call, and not-ready agent counts. Offered, handled, abandoned, service level, and ACW are intentionally `null` until a separate statistic source and field definitions are validated. The REST skill subscription endpoint concerns **interactions** and is not used for these queue metrics.

The service keeps one in-process session and cache for its viewers. Run a single instance for this beta; production scaling needs shared coordination to avoid separate sessions per replica. Review your domain's API limits and the permitted refresh interval with Five9 before increasing polling frequency. The five starter names are examples. The catalog comes from the domain queue endpoint. If none match, the first five returned skills become the starting view. Manage Views can search the domain catalog and add skills to a view. The supervisor account must have permission to read snapshots for chosen skills; a catalog listing alone does not prove snapshot access. The backend monitors a bounded union of selected skills across viewers (40 by default; `FIVE9_MAX_MONITORED_SKILLS` can adjust this after API capacity review).

**Next validation:** With the service account provisioned, confirm the login response, metadata host, queue IDs, and snapshot fields in your domain. Then map the remaining KPI definitions from the Five9 statistics metadata/stream or Statistics Web Services API using real samples and document their time windows. Do not send credentials in chat.
