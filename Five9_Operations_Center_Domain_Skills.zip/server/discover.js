import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { Five9Feed } from './five9.js';

const ENDPOINT = 'https://api.five9.com/wssupervisor/v13/AdminWebService';
const NS = 'http://service.admin.ws.five9.com/';
const OUTPUT = 'five9-field-report.json';
const FIELDS = [
  'Skill Name','Agents Logged In','Agents Ready For Calls','Agents On Call','Agents Not Ready For Calls','Calls In Queue','Current Longest Queue Time',
  'Campaign Name','Service Level (Queue)','Service Level (Talk)','Total Calls','Handled Calls','Calls Abandoned','Calls Connected','Avg Wrap Time','Avg Handle Time','Longest Queue Time'
];
const escaped = s => String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const decode = s => String(s).replace(/&#(x[0-9a-f]+|\d+);|&(amp|lt|gt|quot|apos);/gi,(_,code,named) => code ? String.fromCodePoint(code[0].toLowerCase()==='x'?parseInt(code.slice(1),16):Number(code)) : ({amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"})[named.toLowerCase()]);
function content(xml,name){const pattern=new RegExp(`<(?:(?:[\\w.-]+):)?${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/(?:(?:[\\w.-]+):)?${name}>`,'i');return xml.match(pattern)?.[1]??null}
function elements(xml,name){const pattern=new RegExp(`<(?:(?:[\\w.-]+):)?${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/(?:(?:[\\w.-]+):)?${name}>`,'gi');return [...xml.matchAll(pattern)].map(m=>m[1])}
function values(xml){return elements(xml,'data').map(x=>decode(x.trim()))}
export function parseStatistics(xml){
  const fault=content(xml,'faultstring'); if(fault)throw new Error('SOAP fault: '+decode(fault).slice(0,180));
  const result=content(xml,'return');if(result==null)throw new Error('Statistics response did not contain return data');
  const columns=values(content(result,'columns')||'');
  const rows=elements(result,'rows').map(row=>values(row));
  if(!columns.length)throw new Error('Statistics response has no column names');
  return {columns,rows:rows.map(cells=>Object.fromEntries(columns.map((key,i)=>[key,cells[i]??null])))};
}
function envelope(method,body=''){return `<?xml version="1.0" encoding="UTF-8"?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="${NS}"><soapenv:Header/><soapenv:Body><ser:${method}>${body}</ser:${method}></soapenv:Body></soapenv:Envelope>`}
class SoapClient {
  constructor(username,password,endpoint=ENDPOINT,fetcher=fetch){this.username=username;this.password=password;this.endpoint=endpoint;this.fetcher=fetcher;this.cookie=''}
  async call(method,body=''){
    const response=await this.fetcher(this.endpoint,{method:'POST',headers:{'Content-Type':'text/xml;charset=UTF-8',SOAPAction:'""',Authorization:'Basic '+Buffer.from(`${this.username}:${this.password}`).toString('base64'),...(this.cookie?{Cookie:this.cookie}:{})},body:envelope(method,body),signal:AbortSignal.timeout(18000)});
    const setCookies=response.headers.getSetCookie?.()??[];
    if(setCookies.length)this.cookie=setCookies.map(c=>c.split(';')[0]).join('; ');
    const xml=await response.text();
    if(!response.ok){const fault=content(xml,'faultstring');throw new Error(`SOAP HTTP ${response.status}${fault?': '+decode(fault).slice(0,160):''}`)}
    const fault=content(xml,'faultstring');if(fault)throw new Error('SOAP fault: '+decode(fault).slice(0,160));
    return xml;
  }
  start(){const tz=-new Date().getTimezoneOffset()*60000;return this.call('setSessionParameters',`<viewSettings><forceLogoutSession>false</forceLogoutSession><rollingPeriod>Minutes30</rollingPeriod><shiftStart>0</shiftStart><statisticsRange>CurrentDay</statisticsRange><timeZone>${tz}</timeZone></viewSettings>`)}
  getStatistics(type){return this.call('getStatistics',`<statisticType>${escaped(type)}</statisticType>`)}
  async stop(){try{await this.call('closeSession')}catch{}}
}
function selectStats(parsed){return {columns:parsed.columns.filter(c=>FIELDS.includes(c)),rows:parsed.rows.map(row=>Object.fromEntries(Object.entries(row).filter(([key])=>FIELDS.includes(key))))}}
function metadataSummary(metadata){const arr=Array.isArray(metadata)?metadata:Object.values(metadata||{}).flat().filter(x=>x&&typeof x==='object');return arr.filter(x=>['SKILL','CAMPAIGN'].includes(x.resource)).map(x=>({resource:x.resource,dataSource:typeof x.dataSource==='string'?x.dataSource:null,fields:(x.fields||[]).map(f=>({name:f.name,type:f.type}))}))}
function safeError(err,env){
  let message=String(err?.message||err);
  for(const secret of [env.FIVE9_PASSWORD,env.FIVE9_USERNAME]) if(secret) message=message.replaceAll(secret,'[redacted]');
  return message.slice(0,240);
}
export async function discover(env=process.env,fetcher=fetch){
  const feed=new Five9Feed(env,fetcher);if(!feed.configured)throw new Error('Five9 username, password and domain are required');
  const report={generatedAt:new Date().toISOString(),scope:'Five9 skill and inbound campaign field discovery; no credentials, tokens, agent names or customer records',domainMatch:false,rest:{},soap:{}};
  await feed.tick();
  if(feed.getState().status!=='live')throw new Error(safeError(feed.getState().message||'Five9 REST connection failed',env));
  report.domainMatch=true;
  report.rest.snapshot=feed.getState().skills.map(({name,waiting,longest,logged,ready,onCall,notReady})=>({name,waiting,longest,logged,ready,onCall,notReady}));
  try{const metadata=await feed.supervisor('stats_metadata');report.rest.metadata=metadataSummary(metadata)}catch(err){report.rest.metadataError=safeError(err,env)}
  await feed.stop();
  const soap=new SoapClient(env.FIVE9_USERNAME,env.FIVE9_PASSWORD,env.FIVE9_SOAP_ENDPOINT||ENDPOINT,fetcher);
  try{
    await soap.start();
    for(const type of ['ACDStatus','InboundCampaignStatistics']){
      try{report.soap[type]=selectStats(parseStatistics(await soap.getStatistics(type)))}catch(err){report.soap[type]={error:safeError(err,env)}}
    }
  }catch(err){report.soap.error=safeError(err,env)}finally{await soap.stop()}
  return report;
}

if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url){
  try{
    const report=await discover();await writeFile(OUTPUT,JSON.stringify(report,null,2)+'\n',{flag:'w',mode:0o600});
    console.log(`Saved ${OUTPUT}. Review it before sharing. No password or session token is included.`);
    console.log('REST snapshot: '+report.rest.snapshot?.length+' skills; SOAP: '+Object.keys(report.soap).join(', '));
    if(report.soap.error)console.log('SOAP needs follow-up: '+report.soap.error);
  }catch(err){console.error('Discovery failed: '+safeError(err,process.env));process.exitCode=1}
}
