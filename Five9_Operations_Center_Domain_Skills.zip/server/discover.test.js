import test from 'node:test';
import assert from 'node:assert/strict';
import {parseStatistics} from './discover.js';

test('parses SOAP statistics columns and rows without attaching an agent record',()=>{
 const xml='<env:Envelope><env:Body><ns2:getStatisticsResponse><return><columns><values><data>Campaign Name</data><data>Service Level (Queue)</data><data>Handled Calls</data></values></columns><rows><values><data>Inbound A</data><data>87.4</data><data>42</data></values></rows><timestamp>123</timestamp></return></ns2:getStatisticsResponse></env:Body></env:Envelope>';
 assert.deepEqual(parseStatistics(xml),{columns:['Campaign Name','Service Level (Queue)','Handled Calls'],rows:[{'Campaign Name':'Inbound A','Service Level (Queue)':'87.4','Handled Calls':'42'}]});
});
test('rejects an upstream SOAP fault',()=>{
 assert.throws(()=>parseStatistics('<Fault><faultstring>Unsupported statistic type</faultstring></Fault>'),/Unsupported statistic/);
});
