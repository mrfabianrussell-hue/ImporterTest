import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeSnapshot, Five9Feed } from './five9.js';

test('snapshot maps only documented live fields; zero remains zero', () => {
  const r = normalizeSnapshot({inQueueCalls:[],maxQueueDuration:0,loggedInAgentsIds:['a','b'],readyForCallAgentsIds:['a'],onCallAgentsIds:['b'],notReadyForCallAgentsIds:[]});
  assert.equal(r.waiting,0);assert.equal(r.longest,0);assert.equal(r.logged,2);assert.equal(r.ready,1);
  assert.equal(r.service,null);assert.equal(r.offered,null);assert.equal(r.acw,null);
});
test('unconfigured feed makes no Five9 request', async () => {
  const feed = new Five9Feed({}, () => {throw new Error('unexpected request')});
  await feed.tick(); assert.equal(feed.getState().status,'unconfigured');
});
test('connects through regional login and routes snapshots without exposing credentials', async () => {
  const calls=[];
  const host='app-scl.five9.com';
  const fetcher=async (url, options) => {
    calls.push({url,options});
    const data=url.endsWith('/auth/login') ? {tokenId:'private-token',userId:'500',orgId:'109388',context:{farmId:'12'},metadata:{dataCenters:[{active:true,apiUrls:[{host,port:'443'}]}]}} :
      url.endsWith('/auth/metadata') ? {dataCenters:[{active:true,apiUrls:[{host,port:'443'}]}]} :
      url.endsWith('/login_state') ? 'WORKING' :
      url.endsWith('/skills') ? [{name:'CSRADV - CEBU',id:'42'}] :
      url.endsWith('/skills/42/snapshot') ? {inQueueCalls:[{}],maxQueueDuration:39000,loggedInAgentsIds:['a'],readyForCallAgentsIds:['a'],onCallAgentsIds:[],notReadyForCallAgentsIds:[]} : null;
    return {ok:true,status:200,text:async()=>JSON.stringify(data)};
  };
  const feed=new Five9Feed({FIVE9_USERNAME:'supervisor',FIVE9_PASSWORD:'secret',FIVE9_ORG_ID:'109388',FIVE9_SKILL_NAMES:'CSRADV - CEBU'},fetcher);
  await feed.tick();
  assert.equal(feed.getState().status,'live');
  assert.equal(feed.getState().skills[0].waiting,1);
  assert.equal(feed.getState().skills[0].longest,39);
  assert.equal(feed.getState().skills[0].service,null);
  assert.equal(JSON.stringify(feed.getState()).includes('secret'),false);
  assert.equal(calls[2].options.headers.Authorization,'Bearer-private-token');
  assert.equal(calls[2].options.headers.farmId,'12');
  assert.ok(calls.some(c=>c.url.endsWith('/orgs/109388/skills')));
  assert.equal(calls.length,5);
});
test('supervisor catalog can add a skill beyond the initial view and reuse the cached session',async()=>{
 const calls=[];
 const fetcher=async(url,options)=>{
  calls.push(url);
  let value;
  if(url.endsWith('/auth/login')) value={tokenId:'t',userId:'5',orgId:'109388',context:{farmId:'1'},metadata:{dataCenters:[{active:true,apiUrls:[{host:'app-scl.five9.com',port:'443'}]}]}};
  else if(url.endsWith('/auth/metadata'))value={dataCenters:[{active:true,apiUrls:[{host:'app-scl.five9.com',port:'443'}]}]};
  else if(url.endsWith('/login_state'))value='WORKING';
  else if(url.endsWith('/skills'))value=[{name:'CSRADV - CEBU',id:'42'},{name:'New Skill',id:'43'}];
  else if(url.endsWith('/snapshot'))value={inQueueCalls:[],maxQueueDuration:0,loggedInAgentsIds:[],readyForCallAgentsIds:[],onCallAgentsIds:[],notReadyForCallAgentsIds:[]};
  return {ok:true,status:200,text:async()=>JSON.stringify(value)};
 };
 const feed=new Five9Feed({FIVE9_USERNAME:'u',FIVE9_PASSWORD:'p',FIVE9_ORG_ID:'109388',FIVE9_SKILL_NAMES:'CSRADV - CEBU'},fetcher);
 await feed.tick();assert.deepEqual(feed.getState().catalog,['CSRADV - CEBU','New Skill']);
 feed.addMonitored(['New Skill']);await new Promise(resolve=>setTimeout(resolve,0));
 assert.equal(feed.getState().skills.some(x=>x.name==='New Skill'),true);
 assert.equal(calls.filter(x=>x.endsWith('/auth/login')).length,1);
 assert.throws(()=>feed.addMonitored(['Unassigned']),/unavailable/);
});
test('failed supervisor setup retains the original error and retries login on next poll', async () => {
 let logins=0, fail=true;
 const fetcher=async url=>{
  let value;
  if(url.endsWith('/auth/login')) { logins++; value={tokenId:'t',userId:'5',orgId:'109388',context:{farmId:'1'},metadata:{dataCenters:[{active:true,apiUrls:[{host:'app-scl.five9.com',port:'443'}]}]}} }
  else if(url.endsWith('/auth/metadata')) value={dataCenters:[{active:true,apiUrls:[{host:'app-scl.five9.com',port:'443'}]}]};
  else if(url.endsWith('/login_state')) value='WORKING';
  else if(url.endsWith('/skills')) { if(fail) throw new Error('Skill catalog request failed'); value=[{name:'CSRADV - CEBU',id:'42'}] }
  else if(url.endsWith('/snapshot')) value={inQueueCalls:[],maxQueueDuration:0,readyForCallAgentsIds:[]};
  return {ok:true,status:200,text:async()=>JSON.stringify(value)};
 };
 const feed=new Five9Feed({FIVE9_USERNAME:'u',FIVE9_PASSWORD:'p',FIVE9_ORG_ID:'109388',FIVE9_SKILL_NAMES:'CSRADV - CEBU'},fetcher);
 await feed.tick(); assert.equal(feed.getState().status,'error'); assert.equal(feed.getState().message,'Skill catalog request failed');
 fail=false; await feed.tick(); assert.equal(feed.getState().status,'live'); assert.equal(logins,2);
});
test('upstream HTTP error identifies its operation without exposing the request URL', async () => {
 const feed=new Five9Feed({FIVE9_USERNAME:'user',FIVE9_PASSWORD:'secret',FIVE9_ORG_ID:'109388'},async()=>({ok:false,status:435}));
 await feed.tick();
 assert.equal(feed.getState().message,'Five9 login: HTTP 435');
 assert.equal(JSON.stringify(feed.getState()).includes('secret'),false);
});
test('unmatched starter names use domain skills', async () => {
 const fetcher=async url=>{
  const value=url.endsWith('/auth/login')?{tokenId:'t',userId:'5',orgId:'109388',context:{farmId:'1'},metadata:{dataCenters:[{active:true,apiUrls:[{host:'app-scl.five9.com',port:'443'}]}]}}:
   url.endsWith('/auth/metadata')?{dataCenters:[{active:true,apiUrls:[{host:'app-scl.five9.com',port:'443'}]}]}:
   url.endsWith('/login_state')?'WORKING':url.endsWith('/skills')?[{name:'Actual Skill',id:'9'}]:
   {inQueueCalls:[],maxQueueDuration:0,readyForCallAgentsIds:[]};
  return {ok:true,status:200,text:async()=>JSON.stringify(value)};
 };
 const feed=new Five9Feed({FIVE9_USERNAME:'u',FIVE9_PASSWORD:'p',FIVE9_ORG_ID:'109388'},fetcher);
 await feed.tick(); assert.equal(feed.getState().status,'live');
 assert.deepEqual(feed.getState().catalog,['Actual Skill']);
 assert.deepEqual(feed.getState().skills.map(s=>s.name),['Actual Skill']);
});
test('domain catalog includes queues beyond supervisor assignments', async () => {
 const calls=[];
 const fetcher=async url=>{
  calls.push(url);
  const value=url.endsWith('/auth/login')?{tokenId:'t',userId:'5',orgId:'109388',context:{farmId:'1'},metadata:{dataCenters:[{active:true,apiUrls:[{host:'app-scl.five9.com',port:'443'}]}]}}:
   url.endsWith('/auth/metadata')?{dataCenters:[{active:true,apiUrls:[{host:'app-scl.five9.com',port:'443'}]}]}:
   url.endsWith('/login_state')?'WORKING':url.endsWith('/orgs/109388/skills')?[{name:'Manual Outbound',id:'1'},{name:'CSRADV - CEBU',id:'42'},{name:'CSRGEN - ALL',id:'43'}]:
   url.endsWith('/supervisors/5/skills')?[{name:'Manual Outbound',id:'1'}]:{inQueueCalls:[],maxQueueDuration:0,readyForCallAgentsIds:[]};
  return {ok:true,status:200,text:async()=>JSON.stringify(value)};
 };
 const feed=new Five9Feed({FIVE9_USERNAME:'u',FIVE9_PASSWORD:'p',FIVE9_ORG_ID:'109388',FIVE9_SKILL_NAMES:'CSRADV - CEBU'},fetcher);
 await feed.tick(); assert.deepEqual(feed.getState().catalog,['Manual Outbound','CSRADV - CEBU','CSRGEN - ALL']);
 assert.deepEqual(feed.getState().skills.map(s=>s.name),['CSRADV - CEBU']);
 assert.equal(calls.some(url=>url.endsWith('/supervisors/5/skills')),false);
});
