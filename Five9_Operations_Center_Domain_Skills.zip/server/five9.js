// Five9 Supervisor REST API adapter. Secrets and routing tokens never leave this process.
const DEFAULT_SKILLS = ['CSRADV - CEBU', 'CSRADV- ALL', 'CSRADV - ON', 'CSRGEN - ALL', 'CSRGEN - CEBU'];
const LOGIN = 'https://app.five9.com';
const PREFIX = '/supsvcs/rs/svc';
const empty = () => ({ waiting:null, longest:null, service:null, offered:null, handled:null, abandoned:null, logged:null, ready:null, onCall:null, acw:null, notReady:null });

export function normalizeSnapshot(snapshot) {
  const count = key => Array.isArray(snapshot?.[key]) ? snapshot[key].length : null;
  const number = value => Number.isFinite(Number(value)) && value != null ? Number(value) : null;
  return {
    ...empty(),
    waiting: count('inQueueCalls'),
    longest: number(snapshot?.maxQueueDuration) == null ? null : Math.round(number(snapshot.maxQueueDuration) / 1000),
    logged: count('loggedInAgentsIds'),
    ready: count('readyForCallAgentsIds'),
    onCall: count('onCallAgentsIds'),
    notReady: count('notReadyForCallAgentsIds')
  };
}

function activeHost(metadata) {
  const center = metadata?.dataCenters?.find(x => x.active) ?? metadata?.dataCenters?.[0];
  const endpoint = center?.apiUrls?.[0];
  if (!endpoint?.host) throw new Error('Five9 did not return an active API host');
  const host = String(endpoint.host).toLowerCase();
  if (!/^[a-z0-9.-]+\.five9\.(com|eu)$/.test(host)) throw new Error('Unexpected Five9 API host');
  const port = String(endpoint.port || '443');
  if (port !== '443') throw new Error('Unexpected Five9 API port');
  return `https://${host}`;
}

export class Five9Feed {
  constructor(env = process.env, fetcher = fetch) {
    this.env = env;
    this.fetcher = fetcher;
    this.names = (env.FIVE9_SKILL_NAMES || DEFAULT_SKILLS.join('|')).split('|').map(x => x.trim()).filter(Boolean);
    this.catalog = [];
    this.skills = [];
    this.monitored = new Set(this.names);
    this.cache = new Map();
    this.maxSkills = Math.max(5, Math.min(120, Number(env.FIVE9_MAX_MONITORED_SKILLS) || 40));
    this.orgId = String(env.FIVE9_ORG_ID || '');
    this.configured = Boolean(env.FIVE9_USERNAME && env.FIVE9_PASSWORD && this.orgId);
    this.interval = Math.max(15, Math.min(120, Number(env.FIVE9_POLL_SECONDS) || 30)) * 1000;
    this.session = null;
    this.timer = null;
    this.running = false;
    this.state = { mode:'live', status:this.configured?'connecting':'unconfigured', updatedAt:null, skills:[], message:null };
  }
  async request(url, options = {}, session = this.session) {
    const headers = { Accept:'application/json', 'Content-Type':'application/json', ...options.headers };
    if (session) {
      headers.Authorization = `Bearer-${session.token}`;
      headers.farmId = session.farmId;
    }
    const response = await this.fetcher(url, { ...options, headers, signal:AbortSignal.timeout(12000) });
    if (!response.ok) {
      // Report only the known API operation, never the host, token, response
      // body, credentials, or user ID in a dashboard-visible error.
      const path = new URL(url).pathname;
      const operation = path.endsWith('/auth/login') ? 'login' : path.endsWith('/auth/metadata') ? 'metadata' :
        path.endsWith('/login_state') ? 'supervisor login state' : path.endsWith('/session_start') ? 'supervisor session start' :
        path.endsWith('/skills') ? (path.includes('/orgs/') ? 'domain skill catalog' : 'supervisor skill catalog') : path.endsWith('/snapshot') ? 'skill snapshot' :
        path.endsWith('/auth/logout') ? 'logout' : 'supervisor request';
      const err = new Error(`Five9 ${operation}: HTTP ${response.status}`);
      err.status = response.status;
      throw err;
    }
    if (response.status === 204) return null;
    const body = await response.text();
    return body ? JSON.parse(body) : null;
  }
  async connect() {
    if (!this.configured) return;
    const login = await this.request(`${LOGIN}${PREFIX}/auth/login`, {
      method:'POST', body:JSON.stringify({passwordCredentials:{username:this.env.FIVE9_USERNAME,password:this.env.FIVE9_PASSWORD},policy:'AttachExisting',org:{orgId:this.orgId}})
    }, null);
    if (!login?.tokenId || !login?.userId || !login?.context?.farmId) throw new Error('Five9 login response missing session fields');
    if (String(login.orgId) !== this.orgId) throw new Error('Five9 authenticated to a different domain');
    const session = { token:login.tokenId, farmId:String(login.context.farmId), userId:String(login.userId), host:activeHost(login.metadata) };
    this.session = session;
    try {
    const metadata = await this.request(`${LOGIN}${PREFIX}/auth/metadata`, {}, session);
    session.host = activeHost(metadata?.metadata || metadata);
    let state = await this.supervisor('login_state');
    if (state === 'SELECT_STATION' || state?.loginState === 'SELECT_STATION') {
      await this.supervisor('session_start?force=false', {method:'PUT',body:JSON.stringify({stationId:'',stationType:'EMPTY'})});
      state = await this.supervisor('login_state');
    }
    const loginState = typeof state === 'string' ? state : state?.loginState;
    if (loginState !== 'WORKING') throw new Error(`Supervisor requires login action: ${loginState || 'unknown state'}`);
    const skills = await this.request(`${session.host}${PREFIX}/orgs/${encodeURIComponent(this.orgId)}/skills`);
    if (!Array.isArray(skills)) throw new Error('Unexpected domain skill list');
    this.catalog = skills.filter(s => s?.name && s?.id != null).map(s => ({name:String(s.name).trim(),id:String(s.id)}));
    if (!this.catalog.length) throw new Error('No skills returned for this domain');
    // Starter names are examples; the domain catalog is authoritative.
    if (!this.catalog.some(s => this.monitored.has(s.name))) {
      this.monitored = new Set(this.catalog.slice(0, 5).map(s => s.name));
    }
    this.skills = this.catalog.filter(s => this.monitored.has(s.name));
    } catch (err) {
      // A failed setup must retry login; otherwise the next poll skips setup
      // and attempts to iterate a skill list that was never loaded.
      this.session = null;
      this.skills = [];
      this.catalog = [];
      throw err;
    }
  }
  addMonitored(names) {
    if (!Array.isArray(names) || names.length > 120 || names.some(n => typeof n !== 'string' || n.length > 150)) throw new Error('Invalid skill selection');
    const unique = new Set([...this.monitored].filter(name => this.catalog.some(s => s.name === name)).concat(names));
    if (unique.size > this.maxSkills) throw new Error(`Maximum ${this.maxSkills} monitored skills for this beta`);
    for (const name of names) if (!this.catalog.some(s => s.name === name)) throw new Error(`Skill unavailable: ${name}`);
    this.monitored = unique;
    this.skills = this.catalog.filter(s => unique.has(s.name));
    void this.tick();
  }
  supervisor(path, options = {}) {
    if (!this.session) throw new Error('Five9 session unavailable');
    return this.request(`${this.session.host}${PREFIX}/supervisors/${encodeURIComponent(this.session.userId)}/${path}`, options);
  }
  async tick() {
    if (!this.configured || this.running) return;
    this.running = true;
    try {
      if (!this.session) await this.connect();
      for (const skill of this.skills) {
        const snapshot = await this.supervisor(`skills/${encodeURIComponent(skill.id)}/snapshot`);
        this.cache.set(skill.name,{name:skill.name, ...normalizeSnapshot(snapshot)});
      }
      this.state = {mode:'live',status:'live',updatedAt:new Date().toISOString(),catalog:this.catalog.map(s=>s.name),skills:[...this.cache.values()],message:null};
    } catch (err) {
      if ([401,403,500].includes(err.status)) this.session = null;
      this.state = {...this.state,status:this.state.updatedAt?'stale':'error',message:err.message};
    } finally { this.running = false }
  }
  start() {
    if (!this.configured || this.timer) return;
    void this.tick();
    this.timer = setInterval(() => void this.tick(), this.interval);
    this.timer.unref?.();
  }
  async stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    const session = this.session;
    this.session = null;
    if (session) {
      try { await this.request(`${session.host}${PREFIX}/auth/logout`, {method:'POST'}, session); } catch {}
    }
  }
  getState() {
    const stale = this.state.updatedAt && Date.now()-Date.parse(this.state.updatedAt) > this.interval*3;
    const current = {...this.state,catalog:this.catalog.map(s=>s.name)};
    return stale && current.status === 'live' ? {...current,status:'stale',message:'Last Five9 update is overdue'} : current;
  }
}
