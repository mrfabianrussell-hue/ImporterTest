import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Five9Feed } from './five9.js';

const root = resolve(fileURLToPath(new URL('../dist/', import.meta.url)));
const feed = new Five9Feed();
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml'};
const authRequired = process.env.AUTH_REQUIRED === 'true';
if (process.env.NODE_ENV === 'production' && !authRequired) throw new Error('Set AUTH_REQUIRED=true and require authentication in Azure App Service');
feed.start();
const server = createServer(async (req,res) => {
  // Azure App Service Authentication must be set to Require authentication.
  // This header is a secondary check; it is not a substitute for the platform gate.
  if (authRequired && !req.headers['x-ms-client-principal']) {
    res.writeHead(401, {'Content-Type':'application/json','Cache-Control':'no-store'});
    res.end(JSON.stringify({error:'Authentication required'})); return;
  }
  const pathname = new URL(req.url || '/', 'http://localhost').pathname;
  if (pathname === '/api/live' && req.method === 'GET') {
    res.writeHead(200, {'Content-Type':'application/json','Cache-Control':'no-store'});
    res.end(JSON.stringify(feed.getState())); return;
  }
  if (pathname === '/api/monitor' && req.method === 'POST') {
    try {
      let body='';
      for await (const chunk of req) {body += chunk; if(body.length>10000) throw new Error('Selection too large')}
      feed.addMonitored(JSON.parse(body).skills);
      res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
      res.end(JSON.stringify({ok:true,monitored:feed.skills.length}));
    } catch(err) {
      res.writeHead(400,{'Content-Type':'application/json','Cache-Control':'no-store'});
      res.end(JSON.stringify({error:err.message}));
    }
    return;
  }
  if (pathname.startsWith('/api/')) {res.writeHead(404);res.end();return}
  const filename = resolve(root, '.' + decodeURIComponent(pathname === '/' ? '/index.html' : pathname));
  if (filename !== root && !filename.startsWith(root + sep)) {res.writeHead(403);res.end();return}
  try {
    const info = await stat(filename);
    if (!info.isFile()) throw new Error('Not a file');
    const bytes = await readFile(filename);
    res.writeHead(200, {'Content-Type':types[extname(filename)] || 'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});
    res.end(bytes);
  } catch {res.writeHead(404);res.end('Not found')}
});
server.listen(Number(process.env.PORT) || 3000, process.env.NODE_ENV === 'production' ? '0.0.0.0' : '127.0.0.1', () => {
  if (process.env.NODE_ENV !== 'production') console.log(`Local dashboard ready at http://localhost:${process.env.PORT || 3000}`);
});
for (const signal of ['SIGINT','SIGTERM']) process.once(signal, async () => {
  server.close();
  await feed.stop();
  process.exit(0);
});
