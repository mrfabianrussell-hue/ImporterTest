param([int]$Port = 3000)

$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    $nodeVersion = (& node --version 2>$null)
    if ($LASTEXITCODE -ne 0 -or -not $nodeVersion) { throw 'Install Node.js 20 or newer, then reopen PowerShell.' }
    $major = [int](($nodeVersion -replace '^v','').Split('.')[0])
    if ($major -lt 20) { throw "Node.js 20 or newer is required. Found $nodeVersion." }

    Write-Host 'Five9 Operations Center - local live test' -ForegroundColor Cyan
    Write-Host 'Use a dedicated Five9 Supervisor account. The password is only held in this PowerShell and Node process.'
    $account = Get-Credential -Message 'Enter your Five9 Supervisor username and password'
    if (-not $account) { throw 'No credentials entered.' }
    $env:FIVE9_USERNAME = $account.UserName
    $env:FIVE9_PASSWORD = $account.GetNetworkCredential().Password
    $env:FIVE9_ORG_ID = '109388'
    $env:FIVE9_SKILL_NAMES = 'CSRADV - CEBU|CSRADV- ALL|CSRADV - ON|CSRGEN - ALL|CSRGEN - CEBU'
    $env:FIVE9_POLL_SECONDS = '30'
    $env:PORT = [string]$Port
    $env:AUTH_REQUIRED = 'false'
    $env:NODE_ENV = 'development'

    Write-Host "Once the server says ready, open http://localhost:$Port in your browser. Allow about one minute for the first snapshot." -ForegroundColor Cyan
    Write-Host "For safe connection details, open http://localhost:$Port/api/live in another tab. Press Ctrl+C here to stop." 
    & node server/index.js
} finally {
    foreach ($name in @('FIVE9_USERNAME','FIVE9_PASSWORD','FIVE9_ORG_ID','FIVE9_SKILL_NAMES','FIVE9_POLL_SECONDS','PORT','AUTH_REQUIRED','NODE_ENV')) {
        Remove-Item "Env:$name" -ErrorAction SilentlyContinue
    }
    Pop-Location
}
