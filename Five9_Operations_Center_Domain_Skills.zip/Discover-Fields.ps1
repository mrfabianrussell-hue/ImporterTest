$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    $nodeVersion = (& node --version 2>$null)
    if ($LASTEXITCODE -ne 0 -or -not $nodeVersion) { throw 'Install Node.js 20 or newer, then reopen PowerShell.' }
    Write-Host 'Stop the local dashboard (Ctrl+C) before this one-time field discovery.' -ForegroundColor Cyan
    $account = Get-Credential -Message 'Enter your dedicated Five9 Supervisor username and password'
    if (-not $account) { throw 'No credentials entered.' }
    $env:FIVE9_USERNAME = $account.UserName
    $env:FIVE9_PASSWORD = $account.GetNetworkCredential().Password
    $env:FIVE9_ORG_ID = '109388'
    $env:FIVE9_SKILL_NAMES = 'CSRADV - CEBU|CSRADV- ALL|CSRADV - ON|CSRGEN - ALL|CSRGEN - CEBU'
    & node server/discover.js
    if ($LASTEXITCODE -ne 0) { throw 'Field discovery did not complete. See the message above.' }
    Write-Host 'Review five9-field-report.json, then upload that file here for exact mapping.' -ForegroundColor Green
} finally {
    foreach ($name in @('FIVE9_USERNAME','FIVE9_PASSWORD','FIVE9_ORG_ID','FIVE9_SKILL_NAMES')) {
        Remove-Item "Env:$name" -ErrorAction SilentlyContinue
    }
    Pop-Location
}
