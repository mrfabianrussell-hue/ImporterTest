function kArticleConditions(){const p=kDirect?knowledgePack?.procedures.find(p=>p.id===kDirect):kChosen();if(!p)return '';const links=(knowledgePack.articleLinks||[]).filter(l=>l.sourceId===p.id&&ArticleLinks.usable(l,knowledgePack.procedures));if(!links.length)return '';const button=l=>`<button data-manual-subject="${kEscape(l.targetId)}" title="${kEscape(l.label+' — '+knowledgePack.procedures.find(p=>p.id===l.targetId).heading)}">${kEscape(l.label)} →</button>`;return `<section class="related-strip" aria-label="Related customer needs"><strong>Customer also needs:</strong>${links.slice(0,2).map(button).join('')}${links.length>2?`<button data-more-related>More related articles (${links.length-2})</button>`:''}</section>`}


const mockConditionsPanel=conditionsPanel;conditionsPanel=function(){return knowledgePack?kArticleConditions():mockConditionsPanel()};
render();
