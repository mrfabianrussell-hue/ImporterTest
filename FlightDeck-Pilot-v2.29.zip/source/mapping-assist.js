const MappingAssist=(()=>{
const rules=[
 [/escrow.*(paying|pay|repay).*shortage|pay.*escrow shortage/i,'Escrow','shortage','Shortage options'],
 [/escrow.*(new payment|EA statement|payment change|payment increase)|payment shock/i,'Escrow','escrow','Payment changed'],
 [/escrow.*(balance|disbursement|detail)/i,'Escrow','escrow_balance','Escrow balance'],
 [/\b(escrow|taxes|property tax|tax bill)\b/i,'Escrow',null,''],
 [/\b(PMI|MIP|mortgage insurance|ARM|interest rate|rate change)\b/i,'Loan Terms',null,''],
 [/\b(bankruptcy|deceased|fraud|identity theft|REO|attorney|successor)\b/i,'Special Handling',null,''],
 [/\b(payoff|assumption|assume.*loan)\b/i,'Loan Requests',null,''],
 [/\b(insurance|property damage|hazard|flood|loss draft)\b/i,'Insurance',null,''],
 [/missing payment|payment research|misapplied/i,'Payments','payment_research','Find a payment'],
 [/scheduling a payment|make a payment|one.time payment/i,'Payments','payment','Make a payment'],
 [/\b(payment|ACH|autopay|drafts|late fee|late charge)\b/i,'Payments',null,''],
 [/\b(collection|hardship|forbearance|loss mitigation|delinquen|foreclosure)\w*/i,'Hardship',null,''],
 [/\b(statement|document|1098|credit report|eStatement)\w*/i,'Documents',null,''],
 [/\b(address|telephone|email address|verification|authentication|authorization|multiple loans)\b/i,'Account Maintenance',null,''],
 [/\b(complaint|welcome|servicing transfer|prior servicer|new servicer)\b/i,'Service',null,''],
 [/\b(online|website|password|login|log in|portal|mobile app)\b/i,'Digital',null,''],
 [/\b(campaign|outbound)\b/i,'Outbound',null,'']
];
function suggest(heading){const text=String(heading||'');let rule=rules.find(r=>r[0].test(text));const outbound=/\b(campaign|outbound|pre30 collection|30[–-]59 day collection)\b/i.test(text);if(outbound)rule=[null,'Outbound',/pre30/i.test(text)?'ob_05_29':/30[–-]59/i.test(text)?'ob_30_59':/payment shock/i.test(text)?'escrow':'',''];const candidates=[...new Set(rules.filter(r=>r[0].test(text)).map(r=>r[1]))];const specific=outbound||/^escrow\b/i.test(text)||rules.slice(0,3).some(r=>r[0].test(text))||/\b(PMI|MIP|ARM|mortgage insurance|payoff|assumption|bankruptcy|deceased|fraud)\b/i.test(text);const uncertain=!rule||(!specific&&candidates.length>1);const broad=/^(ESCROW|INSURANCE|PAYMENTS|CUSTOMER SERVICE|FREQUENT CALL TYPES|LOAN TERMS|ACCOUNT VERIFICATION\s*\/\s*AUTHENTICATION)$/i.test(text.trim());const label=text.replace(/^Escrow Analysis\s*[-–—]\s*/i,'').replace(/^Escrow\s*[-–—]\s*/i,'').trim();return {category:uncertain?'Needs placement':rule[1],topicId:uncertain?'':rule?.[2]||'',need:uncertain?'':CustomerNeeds.precise(text)||rule?.[3]||'',confidence:uncertain||broad?'uncertain':'clear',candidates,label:label.slice(0,160),kind:broad?'Possible section heading':'Procedure candidate',reason:!rule?'No specific heading rule matched. OPS can choose a group.':uncertain?'Heading words suggest more than one group: '+candidates.join(', ')+'. OPS placement is needed.':'Heading words suggest '+rule[1]+'. Verify the destination and applicability.'}}
return{suggest};
})();
