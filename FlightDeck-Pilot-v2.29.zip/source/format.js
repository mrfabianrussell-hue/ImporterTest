/* Presentation is separate from the unchanged source excerpt. No HTML or AI rewriting. */
const ProcedureFormat=(()=>{
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function empty(source){return{version:1,sourceText:source,purpose:'',steps:[],conditions:[],notes:'',reviewed:false,tableReviewRequired:false}}
function suggest(source){const f=empty(source),notes=[];let mode='notes',table=false,current=null;
for(const raw of source.split(/\r?\n/)){const line=raw.trim();if(!line){if(mode==='notes')notes.push('');continue}
if(/^if\s*(?:[|/:\t]|\s)\s*then\b/i.test(line)||/^if\s*then$/i.test(line)){table=true;f.tableReviewRequired=true;mode='notes';notes.push(line);continue}
const step=line.match(/^(?:[□☐▢\uF0A7\uF0A8]|\d+[.)])\s*(.+)$/);
if(step){table=false;current={instruction:step[1],details:[]};f.steps.push(current);mode='step';continue}
if(table){notes.push(line);continue}
const objective=line.match(/^(?:objective|purpose)\s*:\s*(.*)$/i);if(objective){f.purpose=objective[1];mode='purpose';continue}
const bullet=line.match(/^[•●▪✓✔\uF0FC\-]\s+(.+)$/);if(bullet){if(current&&mode!=='purpose'){current.details.push(bullet[1]);mode='detail'}else{notes.push(line);mode='notes'}continue}
if(mode==='purpose'){f.purpose+=(f.purpose?' ':'')+line}else if(mode==='step'){current.instruction+=' '+line}else if(mode==='detail'){current.details[current.details.length-1]+=' '+line}else notes.push(line);
}f.notes=notes.join('\n').trim();return f}
function cleanWraps(text){const out=[];for(const line of String(text).split(/\r?\n/)){const t=line.trim();if(!t){out.push('');continue}const last=out.at(-1)||'';if(last&&!/[.!?:;]$/.test(last)&&/^[a-z]/.test(t)&&!/^if\b|^then\b/i.test(t)&&!/[<>|]/.test(last+t))out[out.length-1]+=' '+t;else out.push(t)}return out.join('\n')}
function valid(f,source){const text=s=>typeof s==='string'&&s.length<=1000000;if(f?.version!==1||!text(f.sourceText)||KnowledgeCore.canonical(f.sourceText)!==KnowledgeCore.canonical(source)||!text(f.purpose)||!text(f.notes)||!Array.isArray(f.steps)||f.steps.length>250||!Array.isArray(f.conditions)||f.conditions.length>250||typeof f.reviewed!=='boolean'||typeof f.tableReviewRequired!=='boolean')throw Error('Formatted presentation is invalid or belongs to a different source excerpt.');for(const s of f.steps)if(!text(s.instruction)||!s.instruction.trim()||!Array.isArray(s.details)||s.details.some(x=>!text(x)))throw Error('Each formatted step needs an instruction.');for(const r of f.conditions)if(!text(r.condition)||!r.condition.trim()||!text(r.action)||!r.action.trim())throw Error('Complete both the If and Then fields for each condition.');if(!f.purpose.trim()&&!f.steps.length&&!f.conditions.length&&!f.notes.trim())throw Error('The formatted presentation is empty.');return f}
function render(f){return `${f.purpose?`<section class="formatted-purpose"><h3>Purpose</h3><p>${escape(f.purpose)}</p></section>`:''}${f.steps.length?`<section><h3>Handling steps</h3><ol class="formatted-steps">${f.steps.map(s=>`<li><strong>${escape(s.instruction)}</strong>${s.details.length?`<ul>${s.details.map(t=>`<li>${escape(t)}</li>`).join('')}</ul>`:''}</li>`).join('')}</ol></section>`:''}${f.conditions.length?`<section><h3>Conditions and actions</h3><div style="overflow:auto"><table class="formatted-table"><thead><tr><th scope="col">If</th><th scope="col">Then</th></tr></thead><tbody>${f.conditions.map(r=>`<tr><td>${escape(r.condition)}</td><td>${escape(r.action)}</td></tr>`).join('')}</tbody></table></div></section>`:''}${f.notes?`<section><h3>Additional details</h3><div style="white-space:pre-wrap;overflow-wrap:anywhere">${escape(f.notes)}</div></section>`:''}`}
return{empty,suggest,cleanWraps,valid,render};
})();
