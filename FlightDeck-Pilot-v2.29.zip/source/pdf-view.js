/* Native PDF viewing: only the explicitly attached local document is embedded. */
let kDirect='',kPdfPages={},kPdfZoom='page-width';
const kTextProcedure=kProcedure;
kProcedure=function(p){
 if(!p||!KnowledgeCore.readable(p))return kTextProcedure(p);
 const page=kPdfPages[p.id]||p.start;
 const href=knowledgePdfUrl?knowledgePdfUrl+'#page='+page+'&zoom='+kPdfZoom+'&pagemode=none':'';
 return `<div class="eyebrow">Original flight manual · ${kEscape(knowledgePack.release)}</div><h2>${kEscape(p.heading)}</h2><p class="helper">${kEscape(p.id)} · Mapped PDF pages ${p.start}–${p.end} · ${kEscape(kReviewLabel(p))}</p>${href?`<div class="actions"><button data-pdf-step="-1" data-pdf-id="${kEscape(p.id)}" ${page<=p.start?'disabled':''}>Previous page</button><span>Requested page ${page} of section ${p.start}–${p.end}</span><button data-pdf-step="1" data-pdf-id="${kEscape(p.id)}" ${page>=p.end?'disabled':''}>Next page</button><button data-pdf-zoom="page-width" data-pdf-id="${kEscape(p.id)}">Fit width</button><button data-pdf-zoom="125" data-pdf-id="${kEscape(p.id)}">125%</button><a class="btn secondary" href="${kEscape(href)}" target="_blank" rel="noopener noreferrer">Open larger</a></div><iframe class="manual-pdf" title="Original PDF: ${kEscape(p.heading)}" src="${kEscape(href)}" referrerpolicy="no-referrer"></iframe><p class="helper">The viewer shows whole original pages, which may include neighboring subjects. Use its own zoom and page controls if your browser ignores a page request. If blank, choose Open larger.</p>`:`<div class="alert"><strong>Attach the matching PDF to display the original pages.</strong><p>Your mappings are loaded. Select the same PDF used for this knowledge pack.</p><button data-knowledge-open>Choose matching PDF</button>${kSourceHref(p)?` <a href="${kEscape(kSourceHref(p))}" target="_blank" rel="noopener noreferrer" referrerpolicy="no-referrer">Open internal manual</a>`:''}</div>`}<details><summary>Extracted text / optional formatted answer</summary>${kTextProcedure(p)}</details>`;
};
const kPdfAnswer=answer;
answer=function(){if(knowledgePack&&kDirect)return '<article class="panel answer">'+kProcedure(knowledgePack.procedures.find(p=>p.id===kDirect))+'</article>';return kPdfAnswer()};
const kPdfHome=home;home=function(){kDirect='';kPdfHome()};
const kPdfOpenTopic=openTopic;
openTopic=function(id){kDirect='';kPdfOpenTopic(id)};
function kOpenManual(id){const p=knowledgePack?.procedures.find(p=>p.id===id);if(!p)return;openTopic(p.topicIds.find(id=>topics.some(t=>t.id===id))||'statement');kDirect=id;render();nav();kEl('knowledgeDialog').close()}
const kPdfRender=render;
render=function(){kPdfRender();if(kDirect&&knowledgePack){const p=knowledgePack.procedures.find(p=>p.id===kDirect);if(p&&kEl('pageTitle'))kEl('pageTitle').textContent=p.heading}};
const kPdfNav=nav;
const kNavGroups=NavigationGroups.groups.map(g=>g[0]);
function kNavCategory(p){return NavigationGroups.category(p)}
nav=function(){if(!knowledgePack){kPdfNav();return}kEl('nav').innerHTML='<button data-home>⌂ Frequent questions</button>'+NavigationGroups.groups.map(([c,icon])=>{const list=knowledgePack.procedures.filter(p=>kNavCategory(p)===c);return '<h3><span aria-hidden="true">'+icon+'</span> '+kEscape(c)+'</h3>'+(list.length?list.map(p=>{const selected=kDirect?kDirect===p.id:current&&kChosen()?.id===p.id;return `<button data-manual-subject="${kEscape(p.id)}" ${selected?'aria-current="page" class="active"':''}>${kEscape(p.heading)}${p.status==='unavailable'?' · unavailable':''}</button>`}).join(''):'<p class="helper" style="padding:0 12px;font-size:13px">No published procedures</p>')}).join('')};
const kPdfLoad=kLoad;
kLoad=function(pack){kDirect='';kPdfPages={};kPdfLoad(pack);nav()};
const kPdfClear=kEl('clearKnowledge').onclick;
kEl('clearKnowledge').onclick=()=>{kDirect='';kPdfPages={};kPdfClear();nav()};
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.manualSubject)kOpenManual(b.dataset.manualSubject);if(b.dataset.pdfId){const p=knowledgePack?.procedures.find(p=>p.id===b.dataset.pdfId);if(!p)return;if(b.dataset.pdfStep)kPdfPages[p.id]=Math.max(p.start,Math.min(p.end,(kPdfPages[p.id]||p.start)+Number(b.dataset.pdfStep)));if(b.dataset.pdfZoom)kPdfZoom=b.dataset.pdfZoom;render();if(kEl('knowledgeDialog').open)kEl('knowledgePreview').innerHTML=kProcedure(p)}});
const kPdfCatalog=kRenderCatalog;
kRenderCatalog=function(){kPdfCatalog();if(knowledgePack)kEl('knowledgeCatalog').innerHTML=kEl('knowledgeCatalog').innerHTML.replaceAll('data-kcatalog=','data-manual-subject=')};
nav();
