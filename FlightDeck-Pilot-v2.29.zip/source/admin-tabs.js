/* Local pilot administrative workspace. Hosting must enforce production roles. */
(()=>{
 const dialog=kEl('knowledgeDialog'),body=dialog.querySelector('.knowledge-body');
 const title=document.createElement('h2');title.textContent='Knowledge';kEl('adminKnowledge').appendChild(title);kEl('adminKnowledge').appendChild(body);
 kEl('knowledgeButton').hidden=true;kEl('knowledgeButton').style.display='none';
 for(const b of [...document.querySelectorAll('#adminWorkspace button')])if(['Pilot usage report','Export article feedback','View article feedback'].includes(b.textContent))kEl('adminReportActions').appendChild(b);
 const edit=[...document.querySelectorAll('#adminWorkspace button')].find(b=>b.textContent==='Edit current pack intent routes');if(edit){kEl('adminContentIntro').appendChild(edit);const old=edit.onclick;edit.onclick=()=>{selectAdminTab('content');old()}}
 const priorOpen=openKnowledge;openKnowledge=function(){priorOpen();if(dialog.open)dialog.close();showAdminWorkspace('knowledge')};kEl('knowledgeButton').onclick=openKnowledge;
 const oldShow=showAdminWorkspace;showAdminWorkspace=function(tab='content'){oldShow(tab);if(tab==='knowledge')kStatus()};
 document.addEventListener('click',e=>{if(e.target.closest('[data-open-mapped-procedure]'))kEl('adminWorkspace').classList.add('hidden')});
 const styles=document.createElement('style');styles.textContent='#adminWorkspace [hidden]{display:none!important}#adminTabs [aria-selected="true"]{background:var(--soft);border-color:var(--blue)}#adminKnowledge{flex:1;min-height:0}#adminKnowledge .knowledge-body{max-height:none;overflow:visible}#adminReports{flex:1}';document.head.appendChild(styles);
 const sourceRender=render;render=function(...args){const result=sourceRender(...args);if(!knowledgePack)kEl('content').innerHTML='<h1>Knowledge unavailable</h1><p>Contact your administrator to load the knowledge pack and matching flight manual.</p>';return result};render();
 // Source details remain available to agents.
})();
