/* Navigation suggestions only; never imply procedure applicability. */
const BrowserGroups=(()=>{
const rules=[
 ['Claims & property damage',/claim|property damage|loss draft/i],
 ['Coverage & policy changes',/coverage|deductible|declaration|policy|renewal|cancel|wind|flood/i],
 ['Bills & disbursements',/bill|disburs|not paid|expired/i],
 ['Payment changes & analysis',/analysis|EA statement|payment increase|payment change/i],
 ['Shortages & balances',/shortage|surplus|overage|balance/i],
 ['Automatic payments',/autopay|automatic|recurring|ACH|draft/i],
 ['Payment research',/missing|misapplied|research|returned payment/i],
 ['Making payments',/make a payment|scheduling|one.time payment|payment acceptance/i],
 ['Assistance options',/hardship|afford|forbearance|modification|loss mitigation/i],
 ['Outbound campaigns',/campaign|outbound|DPD|pre30|collection/i]
];
function suggested(p){return rules.find(([,re])=>re.test(p.heading||''))?.[0]||'Other subjects';}
function section(p){return p.browserSection?.trim()||suggested(p);}
function validate(p){if(p.browserSection!==undefined&&(typeof p.browserSection!=='string'||p.browserSection.length>160))throw Error('Invalid category-browser subcategory.');}
return {suggested,section,validate,choices:[...rules.map(r=>r[0]),'Other subjects']};
})();
