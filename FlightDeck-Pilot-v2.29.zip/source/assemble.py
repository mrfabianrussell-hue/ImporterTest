from pathlib import Path
import base64,json
root=Path('pilot-work');out=Path('pilot-package')
pdf=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/pdfjs-dist')
s=(root/'admin.html').read_text().replace('__CORE__',((root/'navigation.js').read_text()+'\n'+(root/'browser-groups.js').read_text()+'\n'+(root/'customer-needs.js').read_text()+'\n'+(root/'mapping-assist.js').read_text()+'\n'+(root/'intent-core.js').read_text()+'\n'+(root/'core.js').read_text()+'\n'+(root/'format.js').read_text()+'\n'+(root/'article-links.js').read_text())).replace('__MAPPINGS__',(root/'mappings.json').read_text()).replace('__CATALOG__',(root/'catalog.json').read_text()).replace('__FORMAT_EDITOR__',(root/'format-editor.js').read_text()).replace('__BATCH_MAPPINGS__',(root/'batch-mappings.js').read_text()).replace('__ARTICLE_LINKS_ADMIN__',(root/'article-links-admin.js').read_text()).replace('__MAPPING_EDITOR__',(root/'mapping-editor.js').read_text()).replace('__RELIABILITY__',(root/'reliability.js').read_text()).replace('__DEMO_REVIEW__',(root/'demo-review.js').read_text()).replace('__INTENT_ADMIN__',(root/'intent-admin.js').read_text()+'\n'+(root/'review-polish.js').read_text()+'\n'+(root/'admin-enhancements.js').read_text())
assets={group:{f.name:base64.b64encode(f.read_bytes()).decode() for f in (pdf/directory).iterdir() if f.suffix in extensions} for group,directory,extensions in [('fonts','standard_fonts',['.pfb','.ttf']),('cmaps','cmaps',['.bcmap']),('wasm','wasm',['.wasm'])]}
s=s.replace('__PDF_ASSETS__',json.dumps(assets))
for token,name in [('__PDF_MAIN__','pdf.min.mjs'),('__PDF_WORKER__','pdf.worker.min.mjs')]:s=s.replace(token,base64.b64encode((pdf/'legacy'/'build'/name).read_bytes()).decode())
s=s.replace('AgentOS','FlightDeck').replace('Frequent questions','Quick answers').replace('applyFlightDeck','applyAgentOS').replace('applyToFlightDeck','applyToAgentOS')
(out/'knowledge-admin.html').write_text(s)
(out/'PDFJS-LICENSE.txt').write_text((pdf/'LICENSE').read_text()+'\n\nSTANDARD FONT LICENSES\n'+ '\n'.join(f.read_text() for f in (pdf/'standard_fonts').glob('LICENSE*'))+'\n\nCMAP LICENSE\n'+(pdf/'cmaps'/'LICENSE').read_text())
s=Path('pilot-work/base-agent.html').read_text().replace('v2.8','v2.9').replace('__NAVIGATION__',(root/'navigation.js').read_text())
text_css='.textLayer{'+(pdf/'web'/'pdf_viewer.css').read_text().split('.textLayer{',1)[1].split('.annotationLayer{',1)[0]
s=s.replace('</style>',(root/'reader.css').read_text()+'\n'+(root/'v222.css').read_text()+'\n'+text_css+'</style>')
s=s.replace('<button id="theme"','<button id="knowledgeButton">Knowledge</button><button id="theme"')
s=s.replace('<script>\n/*', (root/'knowledge-dialog.html').read_text()+'\n<script>\n/*',1) if '<script>\n/*' in s else s.replace('<script>\nconst WORKFLOWS=',(root/'knowledge-dialog.html').read_text()+'\n<script>\nconst WORKFLOWS=',1)
# Find opening script directly if the original contains a different whitespace boundary.
if 'id="knowledgeDialog"' not in s:s=s.replace('<script>',(root/'knowledge-dialog.html').read_text()+'\n<script>',1)
s=s.replace('</script></body>', '\n'+((root/'browser-groups.js').read_text()+'\n'+(root/'customer-needs.js').read_text()+'\n'+(root/'intent-core.js').read_text()+'\n'+(root/'core.js').read_text()+'\n'+(root/'format.js').read_text()+'\n'+(root/'article-links.js').read_text())+'\n'+(root/'agent-knowledge.js').read_text()+'\n'+(root/'pdf-view.js').read_text()+'\n'+(root/'article-links-agent.js').read_text()+'\n'+(root/'pdf-engine.js').read_text()+'\n'+(root/'category-browser.js').read_text()+'\n'+(root/'workspace.js').read_text()+'\n'+(root/'home-tiles.js').read_text()+'\n'+(root/'intent-agent.js').read_text()+'\n'+(root/'article-preview.js').read_text()+'\n'+(root/'device-library.js').read_text()+'\n'+(root/'favorites.js').read_text()+'\n</script></body>')
s=s.replace('TEST MODE</strong> · Fictional account data and draft guidance.', 'TEST MODE</strong> · No live account data. Guidance is mock unless a reviewed knowledge pack is loaded.')
(out/'index.html').write_text(s)
print('Built admin', (out/'knowledge-admin.html').stat().st_size,'bytes; AgentOS', (out/'index.html').stat().st_size,'bytes')

# Embed the updated importer and fixtures so GitHub needs only index.html.
panel=(root/'admin-panel.html').read_text().replace('__EMBED_ADMIN__',base64.b64encode((out/'knowledge-admin.html').read_bytes()).decode())
for n in (1,2):panel=panel.replace('__EMBED_SAMPLE_'+str(n)+'__',base64.b64encode((out/f'sample-manual-v{n}.pdf').read_bytes()).decode())
s=(out/'index.html').read_text().replace('v2.9','v2.29')
s=s.replace('<button id="knowledgeButton">','<button id="adminButton">Admin</button><button id="knowledgeButton">',1)
s=s.replace('<script>','<div id="adminIntegration">'+panel+'</div>\n<script>',1)
s=s.replace('</script></body>', '\n'+(root/'admin-panel.js').read_text()+'\n'+(root/'usage.js').read_text()+'\n'+(root/'lookup-journey.js').read_text()+'\n'+(root/'compact-reader.js').read_text()+'\n'+(root/'feedback.js').read_text()+'\n'+(root/'admin-tabs.js').read_text()+'\n</script></body>')
(out/'index.html').write_text(s)
print('Integrated FlightDeck',len(s.encode()),'bytes')

s=(out/'index.html').read_text().replace('AgentOS','FlightDeck').replace('Frequent questions','Quick answers').replace('applyFlightDeck','applyAgentOS').replace('applyToFlightDeck','applyToAgentOS')
(out/'index.html').write_text(s)

s=(out/'index.html').read_text().replace('FlightDeck Mortgage •','FlightDeck •').replace('FlightDeck <span>Mortgage</span>','FlightDeck')
(out/'index.html').write_text(s)
